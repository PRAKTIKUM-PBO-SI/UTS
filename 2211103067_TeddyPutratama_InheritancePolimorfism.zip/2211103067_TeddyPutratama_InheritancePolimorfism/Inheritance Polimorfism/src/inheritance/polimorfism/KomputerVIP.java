package inheritance.polimorfism;

/**
 Teddy Putratama
 2211103067
 07C
 */
public class KomputerVIP extends Komputer {
    protected boolean vipCard;

    // Constructor
    public KomputerVIP(int jumlahKomputer, String namaWarnet, float hargaPerJam, boolean vipCard) {
        super(jumlahKomputer, namaWarnet, hargaPerJam);
        this.vipCard = vipCard;
    }

    // Overriding method informasi
    @Override
    public void informasi() {
        super.informasi();
        System.out.println("VIP Card: " + (vipCard ? "Ya" : "Tidak"));
    }

    // Method login
    public void login(String username) {
        System.out.println(username + " berhasil login dengan VIP Card.");
    }

    // Overloading method bermain
    public void bermain(int jam) {
        System.out.println("Bermain selama " + jam + " jam.");
    }

    public void bermain(int jam, int menitTambahan) {
        System.out.println("Bermain selama " + jam + " jam dan " + menitTambahan + " menit tambahan.");
    }
}