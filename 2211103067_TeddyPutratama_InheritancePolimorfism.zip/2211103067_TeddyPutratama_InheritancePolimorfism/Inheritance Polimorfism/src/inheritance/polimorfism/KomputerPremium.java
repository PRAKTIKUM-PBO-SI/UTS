package inheritance.polimorfism;

/**
 Teddy Putratama
 2211103067
 07C
 */
public class KomputerPremium extends Komputer {
    protected boolean ruangPrivat;

    public KomputerPremium(int jumlahKomputer, String namaWarnet, float hargaPerJam, boolean ruangPrivat) {
        super(jumlahKomputer, namaWarnet, hargaPerJam);
        this.ruangPrivat = ruangPrivat;
    }

    @Override
    public void informasi() {
        super.informasi();
        System.out.println("Ruang Privat: " + (ruangPrivat ? "Ya" : "Tidak"));
    }

    public void pesan(int nomorKomputer) {
        System.out.println("Komputer nomor " + nomorKomputer + " telah dipesan.");
    }

    public void tambahLayanan(String makanan) {
        System.out.println("Layanan tambahan: Minuman : " + makanan);
    }

    public void tambahLayanan(String makanan, String minuman) {
        System.out.println("Layanan tambahan: Makanan : " + makanan + ", Minuman - " + minuman);
    }
}