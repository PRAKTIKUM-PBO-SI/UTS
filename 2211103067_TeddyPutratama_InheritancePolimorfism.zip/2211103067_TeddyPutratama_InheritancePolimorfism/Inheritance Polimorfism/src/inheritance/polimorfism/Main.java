package inheritance.polimorfism;

/**
Teddy Putratama
 2211103067
 07C
 */
public class Main {
    public static void main(String[] args) {
        Komputer komputer = new Komputer(10, "PC Standar", 5000);
        KomputerVIP komputerVIP = new KomputerVIP(5, "PC VIP", 10000, true);
        KomputerPremium komputerPremium = new KomputerPremium(3, "PC Premium", 15000, true);

        komputer.informasi();
        komputerVIP.informasi();
        komputerVIP.login("Tendi");
        komputerVIP.bermain(2);
        komputerVIP.bermain(2, 30);

        komputerPremium.informasi();
        komputerPremium.pesan(2);
        komputerPremium.tambahLayanan("Extrajos");
        komputerPremium.tambahLayanan("Mie Rebus", "Es Milkita");
    }
}
