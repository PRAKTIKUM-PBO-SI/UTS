package inheritance.polimorfism;

/**
 Teddy Putratama
 2211103067
 07C
 */
public class Komputer {
    int jumlahKomputer;
    String namaWarnet;
    float hargaPerjam;
    
    public Komputer(int jumlahKomputer, String namaWarnet, float hargaPerjam){
        this.namaWarnet = namaWarnet;
        this.jumlahKomputer = jumlahKomputer;
        this.hargaPerjam = hargaPerjam;
        
    }
public void informasi (){
    System.out.println("Pilihan Komputer:"+ namaWarnet);
    System.out.println("Jumlah Komputer Tersedia:"+ jumlahKomputer);
    System.out.println("Jadi total harganya sebesar:"+ hargaPerjam);
    }
}
        

